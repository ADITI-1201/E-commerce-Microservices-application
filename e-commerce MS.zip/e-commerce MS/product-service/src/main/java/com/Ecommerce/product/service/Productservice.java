package com.Ecommerce.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ecommerce.product.dto.ProductRequest;
import com.Ecommerce.product.dto.ProductResponse;
import com.Ecommerce.product.model.Product;
import com.Ecommerce.product.repository.ProductRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class Productservice {
	
	@Autowired
	private ProductRepository productrepo;

	public void createProduct(ProductRequest proreq) {
		Product p=Product.builder()
				.name(proreq.getName())
				.description(proreq.getDescription())
				.price(proreq.getPrice())
				.build();
		
		productrepo.save(p);
		
		
	}

	public List<ProductResponse> getAllProducts() {
		List<Product> products=productrepo.findAll() ;
		return products.stream().map(this::mapToProductResponse).toList();
		
	}
	private  ProductResponse mapToProductResponse(Product p) {
		return ProductResponse.builder()
				.id(p.getId())
				.name(p.getName())
				.description(p.getDescription())
				.price(p.getPrice()).build();
	}
	
	
}
