package com.Ecommerce.inventory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import lombok.Builder;
import com.Ecommerce.inventory.dto.InventoryResponse;
import com.Ecommerce.inventory.repository.InventoryRepository;

import jakarta.transaction.Transactional;

@Service
public class InventoryService {
	
	@Autowired
	private InventoryRepository inventoryrepo;
	
	@Autowired
	private InventoryResponse inventoryresponse;
	
	public List<InventoryResponse> inStock(List<String> name) {
		return inventoryrepo.findByNameIn(name).stream()
				.map(inventory -> 
					InventoryResponse.builder()
					.name(inventory.getName())
					.inStock(inventory.getQuantity() > 0)
					.build()
				).toList();
	}
}
